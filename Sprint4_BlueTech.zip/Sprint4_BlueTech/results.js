export default[
    {
        id: 1,
        title: "Jurassic Word: Dominion",
        geMovie: "Aventura | Ação | Suspense | Ficção Científica",
        time: "02/02/2022",
        status: 'Em progresso',
        url: "https://portal-diariosm.sfo2.digitaloceanspaces.com/wp-content/uploads/2022/05/31120520/Trailer-Oficial-de-Jurassic-World-Dominio-e-lancado-Assista.jpg"

    },
    {
        id: 2,
        title: "Pokemon Sword And Shield",
        geMovie: "RPG",
        time: "15/11/2019",
        status: 'Em progresso',
        url: "https://fs-prod-cdn.nintendo-europe.com/media/images/10_share_images/games_15/nintendo_switch_4/H2x1_NSwitch_PokemonSwordPokemonShield_Combo_enGB.jpg"
    },
    {
        id: 3,
        title: "Naruto",
        geMovie: "Anime",
        time: "15/11/2007",
        status: 'Em progresso',
         url: "https://sm.ign.com/ign_br/screenshot/default/2_7b4m.jpg"
    },
    {
        id: 4,
        title: "Friends",
        geMovie: "Sitcom",
        time: "22/09/1997",
        status: 'Em progresso',
        url: "https://hbomax-images.warnermediacdn.com/images/GXdbR_gOXWJuAuwEAACVH/tileburnedin?size=1280x720&partner=hbomaxcom&v=6a409f09891f75549fdb8d07dc969b63&host=art-gallery.api.hbo.com&language=pt-br&w=1280"
    },
    {
        id: 5,
        title: "Corra",
        geMovie: "Suspense",
        time: "18/05/2017",
        status: 'Em progresso',
        url: "https://institutodecinema.com.br/img/images_(2).jpeg"
    },
    {
        id: 6,
        title: "Fifa 23",
        geMovie: "Simulação | Esporte ",
        time: "27/09/2022",
        status: 'Em progresso',
        url: "https://cdn1.epicgames.com/offer/f5deacee017b4b109476933f7dd2edbd/EGS_EASPORTSFIFA23StandardEdition_EACanada_S1_2560x1440-aaf9c5273c27a485f2cce8cb7e804f5c"
    },
    {
        id: 7,
        title: "One Píece",
        geMovie: "Anime",
        time: "20/10/1999",
        status: 'Em progresso',
        url: "https://sm.ign.com/ign_br/tv/o/one-piece-/one-piece-2_1xby.jpg"
    },
    {
        id: 8,
        title: "Avengers: End Game",
        geMovie: "Aventura | Ação | Suspense | Ficção Científica",
        time: "25/04/2019",
        status: 'Em progresso',
        url: "https://i0.wp.com/pocilga.com.br/wp-content/uploads/2019/04/endgame-1.jpg?fit=800%2C533"
    },
    {
        id: 9,
        title: "Forza Horizon 5",
        geMovie: "Simulação | Corrida",
        time: "05/11/2021",
        status: 'Em progresso',
        url: "https://meuxbox.com.br/wp-content/uploads/2021/05/Forza-Horizon-5.jpg"
    },
    {
        id: 10,
        title: "Peaky Blinders",
        geMovie: "Suspense",
        time: "12/09/2013",
        status: 'Em progresso',
        url: "https://tm.ibxk.com.br/2021/10/07/07155749619281.jpeg?ims=1200x675"
    }
]