export const dialogflowConfig = {
    "type": "service_account",
    "project_id": "strix-sprint",
    "private_key_id": "bcb04a0f1db1833d08cbab3876bac7cacc0cfb30",
    "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDVi0l4cXN/zKJ/\nno8ayU6Qb4e/fFTNwJiAmK75svHt+vtOTq874JFnOhVB/ieW7o4naUi6mO83NeXm\nIbfhwfPQuBEln4eyqTQVY3PnC2d8EPpeFFvyVzUESNhuupKUYNxqJG3a7nBTSSLr\nG4CahLUHCR2G3uDPqWS4gs4j+PVomg0Wr3qLc+R2Tdan0NpnwcW1B30Vaa4pLa8W\ng7ZUSvGJmZMSgR0BSIAaUrgQt/UGBOOJiEfUtB9QiWJDkiAYc4QCK3Nu7oX5feBD\ntDBCf23oysAdsrAw7AeeXdPz9BLM4tXNJ7uyHFwDB2LyOJK4KQkE0FIQ2Jm8u0JV\nH/FXSMUlAgMBAAECggEACZnOD1K2eSf3pFo6H9+uHxNMnKDX5TpEAQAcWdCgTO1M\nUCx8d2o0z1nOq91j5UbLcF0s7mrC0o4jTHH2pPlF33vvFWxzOuadl1qV0uzx1aOj\nxggPTDl8gjlONchAn9gtAL6ri7zNowj2P3DImundg7f2smIh5GQ+yYbkAr0GN5Ik\nchwBI1SA5bwjkzG0X2dqgduD7F1Q6lvgqqglPfQWE4WmyRn63/Gv+6YVjifkx/tV\nP4RZ4Bqn9F88v17AoBTTPGnMLkknQZ3QTkMYFIZNhGlgE1QpiZjnuW+46x5y2IZe\ntocqsGQZ01Wm0UIWn6/Qvtl/BsYqak0ZAqddFkqBXwKBgQD6wy36emHJ5idpqK95\nygB6isweu537erinlFGA1UqPxWNrhEMb2OBSb8OzbS5gcYwRZ+ASuIbDGE8wukiv\nrkiRyt4/6/VZFkEeRBaXQ3jBmhZ1SxnvLZRHOhwoRoYy4ZhmTh/YkDBVz7o1Keoj\n2Oa32mywhf6VZUgw10bhmXDSzwKBgQDaARoWmvwaSB8DiRNtSquJheQoRtWfKT2N\nb3IeuWbQZvdxH5LvOSBgSigLWfPBrtS5CQ+FOEfw9eAsLwQFLCNF3QcJBMpipQXx\nCfafaksAsgVEouCeG2oOS7d/CJSrv5HrWz7deuh8lXABb8fy6POmjpZhndy8wMsv\nDaZYMDd1ywKBgQCdZcWGYyreP8idWXRLTa/fOx/Eap9PKkidZ0uBQl/6vjsZUXuO\nDyM+m0iLZwylHKB+jGTpW0m7S5bpTwQwwYRrfpriJIlr0bwt8y764y741m8iUHGG\n32UjECZ8YUf6x/+Qt5jlphuwwSJwHE8LESpAXKm8Y17ZBym4/mdPU7CtoQKBgAPU\nJyAkgq73e0v1mVi/Cfo1Vsd6TwAnmkQko+10NiEM3eWnt03qQ+5M/x0L7GMHbgb9\n6L7fOSw7NT+xZ7Grj8cHVbtL0T4gRdVw5lrwY/bUKZGGBsngE2HC5KsffHTzvV1T\n0evT38doXHo5+1oBy12ufWejfR/3htoBtF0yI5c3AoGAEYNV87WtwYvmD58yVu8e\nEcgYVpmT4ynmMGL95kHRJRop8Tz7Z3FkL2tSj9clcHixFGvrAwqjS9B1kDc8kPGo\njL1D+5FxD9XravOHVNeTAyZupaOM175AmiU5GS1eaNdTIjifEP8zVC01MXxBbOQl\nCtYArHydEvub2DWcBfWF7ck=\n-----END PRIVATE KEY-----\n",
    "client_email": "dialogflow-react@strix-sprint.iam.gserviceaccount.com",
    "client_id": "106197408937196331699",
    "auth_uri": "https://accounts.google.com/o/oauth2/auth",
    "token_uri": "https://oauth2.googleapis.com/token",
    "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
    "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/dialogflow-react%40strix-sprint.iam.gserviceaccount.com"
  }
  